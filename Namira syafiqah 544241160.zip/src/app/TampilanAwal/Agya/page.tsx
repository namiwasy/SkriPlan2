import React from 'react'

export default function page() {
  return (
    <div>
      <h1>Agya Page</h1>
    </div>
  )
}
